We, the maintainers, pledge to treat all contributors with respect and require that contributors reciprocate.

The maintainers will not tolerate unwelcome, inpolite, abusive or unprofessional behaviour. 

At the discretion of the maintainers, users who persist in behaving in a way that is unwelcome may be subject to a ban.

This applies to all interractions related to this project and any associated projects.
