# Manually updating shipped gadgets

Download the gadget files manuall from their official source into this dir.
Run `./checksum.py <list of files>` to get the checksums.

Update ../../python3/vimspector/gadgets.py with the new version and the
checksums.

