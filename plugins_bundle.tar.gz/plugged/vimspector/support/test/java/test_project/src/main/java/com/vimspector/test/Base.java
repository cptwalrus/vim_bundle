package com.vimspector.test;

public class Base
{
  public String DoSomething()
  {
    String s = new String();
    s.replace( "A", "B" );
    return s;
  }
}
