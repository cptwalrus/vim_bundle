def Main():
  print( "Hello" )
  print( "From" )
  print( "Python" )


Main()
