public enum Foo {
  THING_A,
  THING_C;
}
