<?php
function()
{
    $foo = 'bar';
    // indentation with `o` is correct
}
