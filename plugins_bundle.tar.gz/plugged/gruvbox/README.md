<p align="center"><img src="https://raw.githubusercontent.com/wiki/gruvbox-community/gruvbox/images/gruvbox.svg?sanitize=true"></p>

gruvbox is heavily inspired by [badwolf][], [jellybeans][] and [solarized][].

Designed as a bright theme with pastel 'retro groove' colors and light/dark mode switching in the way of [solarized][]. The main focus when developing gruvbox is to keep colors easily distinguishable, contrast enough and still pleasant for the eyes.

   [badwolf]: https://github.com/sjl/badwolf
   [jellybeans]: https://github.com/nanotech/jellybeans.vim
   [solarized]: http://ethanschoonover.com/solarized

This is a community fork of gruvbox, created to merge recent pull requests and fix recent issues.

If you would like to help gruvbox community edition, please consider becoming a maintainer.
See [this issue](https://github.com/gruvbox-community/gruvbox/issues/93) for more details.

Attention
---------

1. [Read this first](https://github.com/gruvbox-community/gruvbox/wiki/Terminal-specific)
2. Typeface from gallery is [Fantasque Sans Mono](https://github.com/belluzj/fantasque-sans)
3. Typeface from screenshots below is [Fira Mono](https://mozilla.github.io/Fira/)

Screenshots
-----------

Refer [Gallery][] for more syntax-specific screenshots.

   [Gallery]: https://github.com/gruvbox-community/gruvbox/wiki/Gallery

### Dark mode

![Screenshot Dark](http://i.imgur.com/GkIl8Fn.png)

### Light mode

![Screenshot Light](http://i.imgur.com/X75niEa.png)

### Airline theme

![Screenshot Airline](http://i.imgur.com/wRQceUR.png)

Palette
-------

### Dark mode

![Palette Dark](https://raw.githubusercontent.com/wiki/gruvbox-community/gruvbox/images/gruvbox_palette_dark.png)

### Light mode

![Palette Light](https://raw.githubusercontent.com/wiki/gruvbox-community/gruvbox/images/gruvbox_palette_light.png)

Contrast options
----------------

Refer [wiki section][] for contrast configuration and other options.

   [wiki section]: https://github.com/gruvbox-community/gruvbox/wiki/Configuration#ggruvbox_contrast_dark

![Contrast Options](http://i.imgur.com/5MSbe6T.png)

Documentation
-------------

Please check [wiki][] for installation details, terminal-specific setup, troubleshooting, configuration options and others.

   [wiki]: https://github.com/gruvbox-community/gruvbox/wiki

Features
--------

* Lots of style-customization options (contrast, color invertion, italics usage etc.)
* Extended filetype highlighting: Html, Xml, Vim, Clojure, C, Python, JavaScript, TypeScript, JSX via [vim-jsx-pretty][], PureScript, CoffeeScript, Ruby, Objective-C, Go, Lua, MoonScript, Java, Markdown, Haskell, Elixir, C#, Rust via [rust.vim][]
* Supported plugins: [EasyMotion][], [vim-sneak][], [Indent Guides][], [indentLine][], [Rainbow Parentheses][], [Airline][], [Lightline][], [GitGutter][], [Signify][], [ShowMarks][], [Signature][], [Syntastic][], [Ale][], [CtrlP][], [fzf][], [Startify][], [NERDTree][], [Dirvish][]

   [vim-jsx-pretty]: https://github.com/MaxMEllon/vim-jsx-pretty
   [rust.vim]: https://github.com/rust-lang/rust.vim
   [EasyMotion]: https://github.com/Lokaltog/vim-easymotion
   [vim-sneak]: https://github.com/justinmk/vim-sneak
   [Indent Guides]: https://github.com/nathanaelkane/vim-indent-guides
   [indentLine]: https://github.com/Yggdroot/indentLine
   [Rainbow Parentheses]: https://github.com/kien/rainbow_parentheses.vim
   [Airline]: https://github.com/bling/vim-airline
   [Lightline]: https://github.com/itchyny/lightline.vim
   [GitGutter]: https://github.com/airblade/vim-gitgutter
   [Signify]: https://github.com/mhinz/vim-signify
   [ShowMarks]: http://www.vim.org/scripts/script.php?script_id=152
   [Signature]: https://github.com/kshenoy/vim-signature
   [Syntastic]: https://github.com/scrooloose/syntastic
   [Ale]: https://github.com/w0rp/ale
   [CtrlP]: https://github.com/kien/ctrlp.vim
   [fzf]: https://github.com/junegunn/fzf.vim
   [Startify]: https://github.com/mhinz/vim-startify
   [NERDTree]: https://github.com/scrooloose/nerdtree
   [Dirvish]: https://github.com/justinmk/vim-dirvish

Contributions
-------------

See [gruvbox-contrib][] repo for contributions, ports and extras.

[gruvbox-contrib]: https://github.com/gruvbox-community/gruvbox-contrib

ToDo
----

* Filetype syntax highlighting (R, TeX, Swift, Erlang)
* Plugin support (Tagbar, VimPlug)

Self-Promotion
--------------

If you like gruvbox follow the repository on
[GitHub](https://github.com/gruvbox-community/gruvbox) and vote for it on
[vim.org](http://www.vim.org/scripts/script.php?script_id=4349).

License
-------
[MIT/X11][]

   [MIT/X11]: https://en.wikipedia.org/wiki/MIT_License
