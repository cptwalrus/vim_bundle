<!--

Hi, and thanks for reporting an issue with rust.vim. 

Details about your environment will help us assist you.

Please edit this template!

-->

* rust.vim version: <!-- Describe if you use a Vim plugin manager, and you
can use it to tell which version of rust.vim you are running. -->

Steps to reproduce:

<!-- It's best to try to reproduce the issue with the master version of
rust.vim. The issue may already be fixed! -->
_?_

Expected vs. actual behavior:

_?_

Paste debugging info from the Rust Vim plugin via _one_ of the following
commands: `:RustInfo`,  `:RustInfoToClipboard`, or `:RustInfoToFile <filename>`.
<!-- To ensure these commands are available, open a Rust source file first. -->

_?_
