
echo "hello"
sleep 1
echo "help"
sleep 1
echo "hi"
sleep 1
echo "husband"
sleep 1
echo "helper"

